
| airline | departure_time | arrival_time | price | stops | duration | departure_airport | arrival_airport | start_date | return_date | number_of_passengers | other_data |
|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|
| British Airways | 8:15 am | 4:00 pm | $830 | 1 stop (LHR) | 14h 45m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Turkish Airlines | 3:30 pm | 7:10 pm | $836 | nonstop | 10h 40m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Multiple airlines | 4:30 pm | 2:15 pm | $364 | 2 stops (OTP, DUB) | 28h 45m | SAW | YYZ | 2025-04-20 | - | 6 | {} |
| LOT | 1:55 pm | 8:20 pm | $727 | 1 stop (WAW) | 13h 25m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Wizz Air, Air Transat | 4:35 am | 4:00 pm | $691 | 1 stop (LGW) | 18h 25m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Pegasus Airlines, Condor | 11:25 am | 5:55 pm | $823 | 1 stop (FRA) | 13h 30m | SAW | YYZ | 2025-04-20 | - | 6 | {} |
| Lufthansa | 6:10 am | 4:20 pm | $777 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Turkish Airlines, Air Canada | 7:10 am | 2:40 pm | $880 | 1 stop (MUC) | 14h 30m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Air Canada | 6:10 am | 4:20 pm | $812 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Lufthansa, Air Canada | 6:10 am | 4:20 pm | $812 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Turkish Airlines, Condor | 11:30 am | 5:55 pm | $892 | 1 stop (FRA) | 13h 25m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| LOT | 11:25 am | 8:20 pm | $736 | 2 stops (KRK, WAW) | 15h 55m | IST | YYZ | 2025-04-20 | - | 6 | {} |
| Ajet, Icelandair | 10:00 am | 7:10 pm | $713 | 2 stops (MUC, KEF) | 16h 10m | SAW | YYZ | 2025-04-20 | - | 6 | {} |
| Pegasus Airlines, Icelandair | 9:45 am | 7:10 pm | $718 | 2 stops (MUC, KEF) | 16h 25m | SAW | YYZ | 2025-04-20 | - | 6 | {} |
| Egyptair | 6:35 pm | 7:25 am | $727 | 1 stop (CAI) | 19h 50m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Wizz Air, Air Transat | 4:35 am | 4:00 pm | $479 | 1 stop (LGW) | 18h 25m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, WestJet | 7:00 am | 2:15 pm | $577 | 1 stop (DUB) | 14h 15m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Air Canada | 7:10 am | 2:40 pm | $741 | 1 stop (MUC) | 14h 30m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Pegasus Airlines, Condor | 11:25 am | 5:55 pm | $709 | 1 stop (FRA) | 13h 30m | SAW | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Air Canada | 11:30 am | 7:45 pm | $752 | 1 stop (FRA) | 15h 15m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Air Canada | 7:45 am | 4:20 pm | $752 | 1 stop (FRA) | 15h 35m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Air Canada | 7:50 am | 1:50 pm | $871 | 1 stop (VIE) | 13h 00m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Condor | 11:30 am | 5:55 pm | $784 | 1 stop (FRA) | 13h 25m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| LOT | 7:00 am | 5:20 pm | $727 | 1 stop (WAW) | 17h 20m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Ajex, Condor | 10:10 am | 5:55 pm | $743 | 1 stop (FRA) | 14h 45m | SAW | YYZ | 2025-04-19 | - | 6 | {} |
| Turkish Airlines, Air Transat | 7:50 am | 4:00 pm | $774 | 1 stop (LGW) | 15h 10m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| LOT | 7:00 am | 8:20 pm | $727 | 1 stop (WAW) | 20h 20m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Lufthansa | 6:10 am | 4:20 pm | $976 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-19 | - | 6 | {} |
| Air Serbia, PLAY | 4:30 am | 5:45 pm | $595 | 3 stops (BEG, CPH, ...) | 20h 15m | IST | YHM | 2025-04-19 | - | 6 | {} |
| Turkish Airlines | 3:30 pm | 7:10 pm | $981 | nonstop | 10h 40m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Turkish Airlines | 3:30 pm | 7:10 pm | $836 | nonstop | 10h 40m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Multiple airlines | 12:10 am | 2:15 pm | $400 | 2 stops (DLM, DUB) | 45h 05m | SAW | YYZ | 2025-04-21 | - | 6 | {} |
| Turkish Airlines, WestJet | 7:00 am | 2:15 pm | $543 | 1 stop (DUB) | 14h 15m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| LOT | 1:55 pm | 8:20 pm | $727 | 1 stop (WAW) | 13h 25m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Turkish Airlines, Air Canada | 7:15 am | 2:50 pm | $740 | 1 stop | 13h 35m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Wizz Air, Air Transat | 4:35 am | 4:00 pm | $601 | 1 stop (LGW) | 18h 25m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| LOT | 7:00 am | 5:20 pm | $727 | 1 stop (WAW) | 17h 20m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Aegean Airlines | 10:40 am | 4:45 pm | $1,262 | 1 stop (ATH) | 13h 05m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Aegean Airlines, Lufthansa | 10:40 am | 4:45 pm | $1,262 | 1 stop (ATH) | 13h 05m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Aegean Airlines, Air Canada | 10:40 am | 4:45 pm | $1,283 | 1 stop (ATH) | 13h 05m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Lufthansa | 6:10 am | 4:20 pm | $1,075 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Lufthansa, Air Canada | 6:10 am | 4:20 pm | $1,132 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Air Canada | 6:10 am | 4:20 pm | $1,132 | 1 stop (FRA) | 17h 10m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Sky Express, Lufthansa | 9:30 am | 4:45 pm | $1,339 | 1 stop (ATH) | 14h 15m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Sky Express, Aegean Airlines | 9:30 am | 4:45 pm | $1,339 | 1 stop (ATH) | 14h 15m | IST | YYZ | 2025-04-21 | - | 6 | {} |
| Air France | 4:20 am | 3:45 pm | $1,150 | 1 stop (CDG) | 18h 25m | IST | YYZ | 2025-04-21 | - | 6 | {} |
